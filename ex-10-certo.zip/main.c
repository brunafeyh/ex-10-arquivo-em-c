/*10. Fac¸a um programa que receba o nome de um arquivo de entrada e outro de sa´ıda. O
arquivo de entrada contem em cada linha o nome de uma cidade (ocupando 40 caracte- ´
res) e o seu numero de habitantes. O programa dever ´ a ler o arquivo de entrada e gerar ´
um arquivo de sa´ıda onde aparece o nome da cidade mais populosa seguida pelo seu
numero de habitantes

BRUNA CAROLINA DA SILVA FEYH 
22/08/2023
*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

#define MAX 1000

typedef struct{
    char nome[41];
    int habitantes;
} CIDADE;

int getmaiorcidade(char *s, CIDADE y[], int nl, int maior){
    int i;
    FILE *f;
    f = fopen(s, "w");
    if(f == NULL) return errno;
    for(i=0; i<nl;i++){
        if(y[i].habitantes == maior) fprintf(f, "%s : %d", y[i].nome, maior);
    }
    fclose(f);
    return 0;
}

int cidademaior(CIDADE y[], int nl){
    int i, maior = 1;
    for(i=0; i<nl; i++){
        if(y[i].habitantes > maior) maior = y[i].habitantes;
    }
    return maior;
}


int lerarq(char *s, CIDADE y[], int *nl){
    int i;
    FILE *f;
    f = fopen(s, "r");
    if(f == NULL) return errno;
    
    fscanf(f, "%[^0-9]", y[0].nome);
    fscanf(f, "%d%*c", &y[0].habitantes);
    
    for(i=1; fscanf(f, "%d%*c", &y[i].habitantes) != EOF; i++){
        fscanf(f, "%[^0-9]%d%*c", y[i].nome, &y[i].habitantes);
    }
    
    *nl = i;
    fclose(f);
    return 0;
}
int main()
{
    CIDADE p[MAX];

    int erro, nl, maiorn;
    
    erro = lerarq("arq.txt" , p, &nl);
    if(erro != 0) printf("erro de leitura: %d\n", erro);
    
    maiorn = cidademaior(p, nl);
    
    getmaiorcidade("saida.txt", p, nl, maiorn);
    
 
    return 0;
}
